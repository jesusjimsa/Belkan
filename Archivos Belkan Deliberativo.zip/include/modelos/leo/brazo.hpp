#ifndef BRAZOLEO3D_HPP
#define BRAZOLEO3D_HPP

#include "obj3dlib.hpp"
#include <string.h>


class BrazoLeo3D : public Objeto3D{
private:

public:
  BrazoLeo3D();
  ~BrazoLeo3D(){}

};

#endif
