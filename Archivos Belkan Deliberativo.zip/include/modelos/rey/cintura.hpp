#ifndef CINTURAREY3D_HPP
#define CINTURAREY3D_HPP

#include "obj3dlib.hpp"
#include "modelos/rey/pierna.hpp"
#include <string.h>


class CinturaRey3D : public Objeto3D{
private:

public:
  CinturaRey3D();
  ~CinturaRey3D();

};

#endif
