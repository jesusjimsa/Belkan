#ifndef MODELOS_BELKAN
#define  MODELOS_BELKAN

#include "modelos/aldeano/aldeano.hpp"
#include "modelos/rey/rey.hpp"
#include "modelos/jugador/jugador3d.hpp"
#include "modelos/leo/leo.hpp"
#include "modelos/perro/perro.hpp"
#include "modelos/arbol/arbol.hpp"
#include "modelos/item/item.hpp"
#include "modelos/puerta/puerta.hpp"

#endif
