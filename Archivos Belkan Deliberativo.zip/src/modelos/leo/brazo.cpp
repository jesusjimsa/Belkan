#include "modelos/leo/brazo.hpp"


BrazoLeo3D::BrazoLeo3D() : Objeto3D(){
  
}
